define(['angular'], function(angular){
	return angular.module('controllers', []);
});