require 'ex7_empty'
