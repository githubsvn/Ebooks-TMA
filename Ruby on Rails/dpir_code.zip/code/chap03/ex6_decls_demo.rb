#!/usr/bin/env ruby

require '../example'
require 'ex3_template_report'

example %q{
report = HTMLReport.new
}

