

def empty?(s)
  s.length == 0
end
