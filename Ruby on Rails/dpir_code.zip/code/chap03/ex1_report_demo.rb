#!/usr/bin/env ruby

require '../example'


require 'ex1_report'

example %q{

report = Report.new
report.output_report

}
