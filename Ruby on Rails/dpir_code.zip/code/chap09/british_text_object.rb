require 'ex3_renderer'
