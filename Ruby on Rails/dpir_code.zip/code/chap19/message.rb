
foo = nil

foo.do_something()
