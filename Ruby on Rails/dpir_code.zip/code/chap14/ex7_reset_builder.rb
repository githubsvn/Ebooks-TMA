
class LaptopBuilder

  # Lots of code omitted ...

  def reset
    @computer = LaptopComputer.new
  end

end


