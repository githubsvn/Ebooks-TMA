#!/usr/bin/env ruby

require '../../example'



require 'finder'

require 'ex6_multi_backup'

