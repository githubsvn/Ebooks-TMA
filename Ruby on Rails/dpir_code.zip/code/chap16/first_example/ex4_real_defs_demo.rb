#!/usr/bin/env ruby

require '../../example'



require 'finder'

require 'ex3_packrat'
require 'ex4_real_defs'

