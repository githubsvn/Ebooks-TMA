require '../../interpreter/ex1_files'
require '../../interpreter/ex3_operators'

