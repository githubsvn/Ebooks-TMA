
class Car < Vehicle 
  def sunday_drive
    start_engine
    # cruise out into the country and return
    stop_engine
  end
end 
