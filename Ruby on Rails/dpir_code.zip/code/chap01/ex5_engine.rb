class Engine 

  # All sorts of engine related code...

  def start
    # start the engine
  end

  def stop
    # stop the engine
  end
end
