
class GasolineEngine
  def start
    puts 'starting a gas engine'
  end

  def stop
    puts 'stopping a gas engine'
  end
end

class DieselEngine
  def start
    puts 'starting a diesel engine'
  end

  def stop
    puts 'stopping a diesel engine'
  end
end
