class Vehicle

  # All sorts of vehicle related code...

  def start_engine
    # start the engine
  end

  def stop_engine
    # stop the engine
  end
end
