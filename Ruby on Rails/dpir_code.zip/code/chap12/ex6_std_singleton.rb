require 'singleton'

class SimpleLogger
  include Singleton

  # Lots of code deleted...

end
