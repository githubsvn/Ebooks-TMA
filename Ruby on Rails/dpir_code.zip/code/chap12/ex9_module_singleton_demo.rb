#!/usr/bin/env ruby

require '../example'

require 'ex9_module_singleton'


example %q{

ModuleBasedLogger.info('Computer wins chess game.')

}
