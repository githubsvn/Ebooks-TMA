class BankAccount
  attr_accessor :balance

  def initialize(opening_balance)
    @balance = opening_balance
  end
end
