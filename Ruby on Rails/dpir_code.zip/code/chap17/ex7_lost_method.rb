
require 'ex4_base'

class Species < CompositeBase

  # This method is about to be lost!

  def parent_classification
    # ...
  end

  # And there it goes...

  composite_of(:classification)
end
