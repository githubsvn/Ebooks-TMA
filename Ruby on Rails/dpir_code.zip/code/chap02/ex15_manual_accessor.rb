

class BankAccount
  def balance
    return @balance
  end

  def set_balance(new_balance)
    @balance = new_balance
  end

  def balance=(new_balance)
    @balance = new_balance
  end
end
