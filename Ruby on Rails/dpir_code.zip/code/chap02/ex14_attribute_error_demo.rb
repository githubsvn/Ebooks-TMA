#!/usr/bin/env ruby


require 'ex13_account'


my_account = BankAccount.new('russ')
puts(my_account.balance)
