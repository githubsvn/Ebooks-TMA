

class BankAccount
  attr_accessor :balance
  attr_reader :owner
end
