#!/usr/bin/env ruby
require '../example'

example %q{
:a_symbol
:an_other_symbol
:first_name 
}
