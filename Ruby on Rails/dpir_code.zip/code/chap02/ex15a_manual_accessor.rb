

class BankAccount

  def balance
    @balance
  end

end
