
require '../../ex1_message'
