

class DefaultAuthorizer

  def authorized?(message)
    false
  end

end
