This is the example message gateway.
