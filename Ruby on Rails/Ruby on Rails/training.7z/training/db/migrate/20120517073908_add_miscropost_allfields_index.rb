class AddMiscropostAllfieldsIndex < ActiveRecord::Migration
  def up
  	add_index :microposts, [:content, :user_id]
  end

  def down
  	remove_index :microposts, [:content, :user_id]
  end
end
