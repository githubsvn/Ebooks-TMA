# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Training::Application.config.secret_token = 'd55055f2481a2889f5443f0db168bd3896fdec9620604d2996f6f0274ec8011cfe269ad36db076bff060fa7276cdc4ff83961480e527a0bed457f1e1aa446995'
