class ApplicationController < ActionController::Base
  include UsersHelper
  #helper :all 
  protect_from_forgery
end
