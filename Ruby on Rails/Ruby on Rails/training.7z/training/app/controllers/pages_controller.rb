class PagesController < ApplicationController
  def home
  	@home_page = "Hello Home Page"
  end

  def contact
  end

  def help
	@title = "Help"
  end

end
