module UsersHelper

  def search_user(search)
    if search
        return User.find(:all, :conditions => ['name LIKE ? or email LIKE ? ', "%#{search}%", "%#{search}%"])

      else        
         return User.all
         
      end 
  end

  def get_all_users
      return  User.first
  end



end
