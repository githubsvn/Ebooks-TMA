# The Book of Ruby - http://www.sapphiresteel.com

printf("d=%d f=%f o=%o x=%x s=%s\n", 10, 10, 10, 10, 10)
printf("0.04f=%0.04f : 0.02f=%0.02f\n", 10.12945, 10.12945)