# The Book of Ruby - http://www.sapphiresteel.com

x = (10 +
(2*4) )
puts( x )

x = (10
+ (2*4) )
puts( x )

x = (10 \
+ (2*4) )
puts( x )