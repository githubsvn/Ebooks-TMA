The Book Of Ruby

The Book Of Ruby is a free in-depth guide to Ruby programming. 
It is written by Huw Collingbourne and distributed by SapphireSteel 
Software - developers of the Ruby In Steel IDE for Visual Studio.

Download The Latest Version:

All the programs in every chapter in this book are available for 
download as a Zip archive from 

http://www.sapphiresteel.com/The-Book-Of-Ruby 

When you unzip the programs you will find that they are grouped 
into a set of directories � one for each chapter. 

Load Programs into an Editor or IDE:

For the benefit of programmers using Ruby In Steel 
(the Visual Studio IDE developed by the author of this book�s company,
 SapphireSteel Software), you may load the programs as Visual Studio 
 solutions into Ruby In Steel For Visual Studio 2008, with the programs 
 for each chapter arranged on the branches of a tree in the Project Manager. 
 If you are using another editor or IDE, load each Ruby program, one by one, 
 as it is needed. Users of Ruby In Steel for Visual Studio 2005 may import 
 or convert the projects (via the File New or Open menu).

Permissions: 

You may copy or distribute the text and programs of The Book Of Ruby but you 
may not modify them without prior consent of the author nor may you distribute 
the eBook in any form other than that in which it is provided. You may not 
print the text for redistribution. You may, however, print the chapters for your 
own personal use. In no circumstances may you make a charge for The Book Of Ruby 
or for any of its component parts.

The Book of Ruby is Copyright � 2009 Huw Collingbourne.
