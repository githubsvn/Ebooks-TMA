# The Book of Ruby - http://www.sapphiresteel.com

require "yaml"

    arr = ["fred", "bert", "mary"]			
    yaml_arr = YAML.dump( arr )
	puts( yaml_arr )
    p( yaml_arr )
