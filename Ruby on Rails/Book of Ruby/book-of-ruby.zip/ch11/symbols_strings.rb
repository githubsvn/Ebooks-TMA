# The Book of Ruby - http://www.sapphiresteel.com

puts( :helloworld.equal?( :helloworld ) )
puts( "helloworld".equal?( "helloworld" ) )
puts( 1.equal?( 1 ) )