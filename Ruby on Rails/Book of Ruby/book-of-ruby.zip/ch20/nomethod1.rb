# The Book of Ruby - http://www.sapphiresteel.com

def method_missing( methodname ) 
	puts( "#{methodname} does not exist" )
end	

xxx