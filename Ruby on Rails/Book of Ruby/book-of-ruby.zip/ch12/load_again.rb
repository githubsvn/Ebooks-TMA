# The Book of Ruby - http://www.sapphiresteel.com

puts( "Three loads..." )
load "test.rb"
load "test.rb"
load "test.rb"