# The Book of Ruby - http://www.sapphiresteel.com

require( "testmod.rb" )
