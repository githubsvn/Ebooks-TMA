# The Book of Ruby - http://www.sapphiresteel.com

puts( /.*at/.match('The cat sat on the mat!') )
puts( /.*?at/.match('The cat sat on the mat!') )