RAILS_ROOT = 'C:\railstest\blog'
require 'C:\railstest\blog\config\boot.rb'
require 'commands/server'
