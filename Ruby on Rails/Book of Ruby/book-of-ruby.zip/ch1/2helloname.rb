print('Enter your name: ' )
name = gets()
puts( "Hello #{name}" )